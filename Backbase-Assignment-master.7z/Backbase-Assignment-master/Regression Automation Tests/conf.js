exports.config = {
  framework: 'jasmine',
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['HomePageSpec.js', 
  'AddComputerPageSpec.js',
  'UpdateComputerPageSpec.js' ]
}